package myApp;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class myApp implements ActionListener {
    private JLabel Base_Login;
    private JPanel Start;
    private JPanel root_panel;
    private JLabel error_label;
    private JButton a1;
    private JButton a2;
    private JButton a4;
    private JButton a5;
    private JButton a6;
    private JButton a7;
    private JButton a8;
    private JButton a9;
    private JButton a3;
    private JButton a0;
    private JButton aCalculate;
    private JTextArea outputText;
    private JButton aPlus;
    private JButton aMinus;
    private JButton clearButton;

    int val1 = -1;
    int val2 = -1;
    static boolean plus = false;
    static boolean minus = false;
    static boolean cal = false;


    public JPanel create_Base_page()
    {
        a1.addActionListener(this);
        a2.addActionListener(this);
        a3.addActionListener(this);
        a4.addActionListener(this);
        a5.addActionListener(this);
        a6.addActionListener(this);
        a7.addActionListener(this);
        a8.addActionListener(this);
        a9.addActionListener(this);
        a0.addActionListener(this);
        aPlus.addActionListener(this);
        aMinus.addActionListener(this);
        aCalculate.addActionListener(this);
        clearButton.addActionListener(this);
        a1.setActionCommand("1");
        a2.setActionCommand("2");
        a3.setActionCommand("3");
        a4.setActionCommand("4");
        a5.setActionCommand("5");
        a6.setActionCommand("6");
        a7.setActionCommand("7");
        a8.setActionCommand("8");
        a9.setActionCommand("9");


        a0.setActionCommand("0");
        aPlus.setActionCommand("+");
        aMinus.setActionCommand("-");
        aCalculate.setActionCommand("c");
        clearButton.setActionCommand("v");
        outputText.setEditable(false);



        return Start;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("button clicked");

        String pressed = e.getActionCommand();
        if (pressed == "v")
        {
            System.out.println("clear button clicked");

            val1 = val2 = -1;
            plus = minus = false;
            outputText.setText("");
            return;
        }
        String outt;
        if (plus && pressed == "c")
        {
            System.out.println("calculating this plus");
            outt = String.valueOf(val1 + val2);
            outputText.append( "\n" + outt);

        }
        else if(minus && pressed == "c" )
        {
            outt = String.valueOf(val1 - val2);
            outputText.append( "\n" + outt);

        }


        if (pressed == "+") {
            System.out.println("doing this");
            plus = true;
            outputText.append("+");


        } else if (pressed == "-") {
            minus = true;
            outputText.append("-");
        }
        else
        {

            if (val1 == -1) {
                val1 = Integer.parseInt(pressed);

                outputText.append(String.valueOf(val1));

            } else if (val2 == -1) {
                val2 = Integer.parseInt(pressed);
                outputText.append(String.valueOf(val2));


            }

        }
    }
}
