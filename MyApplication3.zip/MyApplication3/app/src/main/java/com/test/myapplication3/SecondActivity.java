package com.test.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView myText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        myText = (TextView) findViewById(R.id.textView2);

        Bundle receiveBundle = this.getIntent().getExtras();
        String receiveValue = receiveBundle.getString("value");
        myText.setText(receiveValue);
        //finish();
    }
}