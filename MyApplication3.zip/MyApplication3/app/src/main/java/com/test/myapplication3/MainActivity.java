package com.test.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button myButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myButton = (Button) findViewById(R.id.myButton);
        myButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String valueString = "Text from First Activity";
                Bundle sendBundle = new Bundle();
                sendBundle.putString("value", valueString);

                Intent i = new Intent(MainActivity.this, SecondActivity.class);
                i.putExtras(sendBundle);
                startActivity(i);
                //finish();
            }
        });A

    }
}