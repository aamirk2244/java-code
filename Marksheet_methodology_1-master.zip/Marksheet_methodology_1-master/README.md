# Marksheet-Methodology
This is a Student CE component marksheet.

Don't Forget to <a href="https://www.youtube.com/channel/UCV8auqEr_jx606MqyeyIPpw?sub_confirmation=1">Subscribe</a> My Channel , like video and share to your friends. If you want to learn any new things then comment over that. We will make new video on that As soon As Possible.

<br>
## Task:
Consider the following database tables for the application.<br>

### Database Table:<br>
#### Name of the table: StudentDetails
<table>
  <tr>
    <th>Column Names</th>
  </tr>
  <tr>
    <td>Roll no. </td>
    <td>Name </td>
    <td>Samester </td>
  </tr>
  <tr>
    <th>Data type with constrains</th>
    <tr>
      <td>Text, Not Null</td>
      <td>Text, Not Null</td>
      <td>Integer, Not Null</td>
  </tr>
  <tr>
    <td>17BIT021</td>
    <td>Yagnik</td>
    <td>6</td>
  </tr>
  <tr>
    <td>17BCE035</td>
    <td>Krish</td>
    <td>6</td>
  </tr>
  </table>

####  Name of the table: CEComponent
<table>
<tr>
      <th>Column Names</th>
</tr>
<tr>
    <td>Roll no. </td>
    <td>Class Test Marks</td>
    <td>Sessional  Marks</td>
    <td>Assignment Marks</td>
</tr>
<tr>
     <th>Data type with Constraints</th>
</tr>
<tr>
    <td>Text, Not Null</td>
    <td>Integer,Not Null</td>
    <td>Integer,Not Null</td>
    <td>Integer,Not Null</td>
</tr>
<tr>
     <th>Sample Data</th>
</tr>
<tr>
    <td>17BIT021</td>
    <td>20</td>
    <td>25</td>
    <td>30</td>
</tr>
<tr>
    <td>17BCE035</td>
    <td>25</td>
    <td>30</td>
  <td>35</td>
</tr>
</table>


# Following functionalities in app:
1) First activity is asked student details according to table StudentDetails. As soon as student clicks
the submit button, update information in StudentDetails table. Validate the fields for appropriate
data type i.e Roll no. is Text type, Semester is Integer type, etc.<br>
2) Second activity is asked student's marks according to table CEComponent. As soon as student clicks
the submit button, it first check that student is registred or not. If register then it allowed to update information in StudentDetails table.


## Images of Output
![11](https://user-images.githubusercontent.com/52067673/88957131-0eab1880-d2bc-11ea-9e88-7772d2ce9c16.PNG)

![12](https://user-images.githubusercontent.com/52067673/88957200-24204280-d2bc-11ea-88b0-db22d7e2e2f0.PNG)

![13](https://user-images.githubusercontent.com/52067673/88957243-3601e580-d2bc-11ea-8ee7-815be95a251f.PNG)
