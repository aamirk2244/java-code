package moheventmanagementsystem;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;


public class Frame extends JFrame {

    
    
private JMenuItem total;
    
    private JButton jButton1;
    private JLabel jLabel1;
    private JPanel jPanel1;
    private JScrollPane jScrollPane1;
    private JTable jTable1;
    private JPopupMenu popup;
    private JMenuItem removeItem;
    private JMenuItem editItem;
    private String filepath = "D:\\Five Projects\\1\\MoHEventManagementSystem\\Data.txt";





    public Frame() throws Exception {
              
        setTitle("MoH Event Management System");
        setResizable(false);
        
        popup = new JPopupMenu();

        removeItem = new JMenuItem("Delete row");
        editItem = new JMenuItem("Edit row");
        total = new JMenuItem("Total");
        
        popup.add(editItem);
        popup.add(removeItem);
        popup.add(total);
    
        jPanel1 = new JPanel();
        jScrollPane1 = new JScrollPane();
        jTable1 = new JTable();
        jLabel1 = new JLabel();
        jButton1 = new JButton();


        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        
        jTable1.setModel(new DefaultTableModel(new Object[][]{}, new String[]{"Promoter",
            "Name", "Budget"}
        ));


        //read the previous data while loading the app
        readData();


        //sorting the table

        jTable1.setAutoCreateRowSorter(true);


        //listener for table to add action for delete and edit
        
        jTable1.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {

                int row = jTable1.rowAtPoint(e.getPoint());

                jTable1.getSelectionModel().setSelectionInterval(row, row);
                if (e.getButton() == MouseEvent.BUTTON3) {
                    popup.show(jTable1, e.getX(), e.getY());
                }
            }
        });


        //remove row button
        removeItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                int rows = jTable1.getSelectedRow();

                model.removeRow(rows);
                try {
                    updateFile();

                } catch (Exception exp) {

                }

            }
        });


        //edit row button
        editItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                int rows = jTable1.getSelectedRow();
                String promoter = JOptionPane.showInputDialog(null, "Enter Promoter:");
                String name = JOptionPane.showInputDialog(null, "Enter Name:");
                String budget = JOptionPane.showInputDialog(null, "Enter Budget:");

                model.setValueAt(promoter, rows, 0);
                model.setValueAt(name, rows, 1);
                model.setValueAt(budget, rows, 2);

                try {
                    updateFile();

                } catch (Exception exp) {

                }

            }
        });

            //edit row button
        total.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                int total =  0 ;

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int rows = jTable1.getRowCount();
        for (int i = 0; i < rows; i++) {

            total += Integer.parseInt(model.getValueAt(i, 2)+""); 
        }
                
                JOptionPane.showMessageDialog(null, "Total Budget is :"+total);
                
            }
        });

    
        
        //setting the view point of the program
        
        jScrollPane1.setViewportView(jTable1);
        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 440, Short.MAX_VALUE)
        );


        jLabel1.setBackground(new java.awt.Color(102, 153, 255));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("MoH Event Management System");

        jButton1.setText("Add");

        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    jButton1ActionPerformed(evt);
                } catch (IOException ex) {
                    System.out.println("Exception");
                }
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(37, 37, 37)
                                                .addComponent(jLabel1)
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                                        .addComponent(jButton1))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }

  
    

    //add button
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) throws IOException {

        String promoter = JOptionPane.showInputDialog(null, "Enter Promoter:");
        String name = JOptionPane.showInputDialog(null, "Enter Name:");
        String budget = JOptionPane.showInputDialog(null, "Enter Budget:");

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.addRow(new Object[]{promoter, name, budget});

        write(promoter, name, budget);

    }


    public void updateFile() throws IOException {

        String promoter;
        String name;
        String budget;

        try {

            FileWriter myWriter = new FileWriter(filepath);

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            int rows = jTable1.getRowCount();
            for (int i = 0; i < rows; i++) {

                promoter = model.getValueAt(i, 0) + "";
                name = model.getValueAt(i, 1) + "";
                budget = model.getValueAt(i, 2) + "";
                myWriter.write(promoter + "," + name + "," + budget + "\n");

            }

            myWriter.close();

        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void write(String promoter, String name, String budget) throws IOException {
        try {
            FileWriter myWriter = new FileWriter(filepath, true);
            myWriter.write(promoter + "," + name + "," + budget + "\n");
            myWriter.close();
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void readData() {
        String data = "";
        String arr[];
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        try {
            File myObj = new File(filepath);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
                arr = data.split(",");
                model.addRow(new Object[]{arr[0], arr[1], arr[2]});
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }

    //Main Method
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Frame().setVisible(true);
                } catch (Exception ex) {
                    System.out.println("Exception");
                } 
                
            }
        });
    }
     
}
