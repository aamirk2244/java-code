# Calculator
A simple android calculator with Stylish Ui

![image](https://user-images.githubusercontent.com/55190831/82928738-8a19e200-9f7a-11ea-9f96-af66d5fe41b7.png)


